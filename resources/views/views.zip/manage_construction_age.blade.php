			@extends('master')
			@section('content');
			
			<!--CONTENT CONTAINER-->
				<!--===================================================-->
				<div id="content-container">
					
					<!--Page Title-->
					<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
					<div id="page-title">
						<h1 class="page-header text-overflow">Manage Construction Year</h1>

						
						
					</div>
					<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
					<!--End page title-->

					
			<!--===================================================-->
				<div id="page-content">
					
					<!-- Basic Data Tables -->
					<!--===================================================-->
					<div class="panel">
						<div class="panel-body">
						@if($user_access[0]->fn_add=='Y')
						  <div class="row">
						      <div class="col-md-12">
							       <a href="#" data-target="#demo-default-modal" data-toggle="modal" class="btn btn-info pull-right" role="button" onclick="city();">Add Construction Year</a>
							  </div>
						  </div>
						  @endif
						  <div class="table-responsive">
							<table class="table table-striped table-bordered" cellspacing="0" width="100%">
								<thead>
									<tr>
										<th>Sr.no.</th>
										<th>Nagar Palika</th>
										<th>Construction Year</th>
										 <th>Action</th>
									</tr>
								</thead>
								<tbody>
									@foreach($asset_name as $index=>$value)
									<tr>
										<td>{{($asset_name->currentpage()-1) * $asset_name->perpage() + $index + 1 }}</td>
										<td>{{$value->nagarpalika}}</td>
										<td>{{$value->age}}</td>
										<td>
										{{-- @if($user_access[0]->fn_delete=='Y')
										<a class="label label-danger" href="#">Delete</a>
										@endif --}}
										@if ($user_access[0]->fn_update == 'Y')
                                                   <a class="label label-success" href="{{ url('/') }}/UpadteConstruction?id={{ $value->id }}">Edit</a>
                                               @endif
										</td>
										
										
									</tr>
									@endforeach
								</tbody>
							</table>
							</div>
							{{$asset_name->links()}}
						</div>
					</div>
					<!--===================================================-->
					<!-- End Striped Table -->
					
				</div>
				</div>
				<div class="modal fade" id="demo-default-modal" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">

				<!--Modal header-->
				<div class="modal-header">
					<button data-dismiss="modal" class="close" type="button">
					<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title">Add Construction Year</h4>
				</div>

				<!--Modal body-->
				{!!Form::Open(array('route'=>'Save.AgeDetails'))!!}
				<div class="modal-body">
				  

					<div class="row">
						 <div class="col-sm-6">
								<div class="form-group">
									<label class="control-label">Nagar Palika</label>
									<select class="form-control" name="ngrpalika" id="nagarpalika" onchange="get_ward_number(this.value);">
										<option value="">--Select Nagar Palika--</option>
									</select>
								</div>
							</div>
						<div class="col-sm-6">
							<div class="form-group">
								<label class="control-label">Select Construction Year</label>
								<select class="form-control" name="year" id="year">
								 <option value="0">--Select Year--</option>
								 <option value="0 To 10">0 To 10</option>
								 <option value="10 To 20">10 To 20</option>
								 <option value="More Than 20">More Than 20</option>
								</select>
							</div>
						</div>
					</div>
				 
				</div>

				<!--Modal footer-->
				<div class="modal-footer">
					<button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
					{!!Form::submit('Submit',array('class'=>'btn btn-success text-uppercase'))!!}
					
				</div>
				{!!Form::Close()!!}
			</div>
		</div>
	</div>
	
				<!--===================================================-->
				<!--End page content-->
			@endsection
@section('script');
	<script>
		$('document').ready(function(e){
			city();
		});
		function city()
		{
			
			$.ajax
			({
				url:"{{url('/')}}/getnagarpalika",
				dataType:'json',
				success:function(data)
				{
					var msg='<option value="">--Select Nagar Palika--</option>';
					for(var i=0;i<data.length;i++)
					{
						msg=msg+'<option value="'+data[i].city+'">'+data[i].city+'</option>';
					}
					$("#nagarpalika").html(msg);
				}
			});
		}
	</script>
	@endsection