
@extends('master')
@section('content');

	
			<!--CONTENT CONTAINER-->
			<!--===================================================-->
			<div id="content-container">
				
				
				<div id="page-content">
					
				
					<div class="row">
						<div class="col-sm-12">
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Assign ward</h3>
								</div>
					
								<!--Block Styled Form -->
								<!--===================================================-->
								{!!Form::Open(array('route'=>'update.ward'))!!}
									<div class="panel-body">
										<div class="row">
										    <div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">Nagar Palika</label>
													<select class="form-control" name="ngrpalika" id="nagarpalika" onchange="get_ward_number(this.value);">
								                        <option value="">--Select Nagar Palika--</option>
													</select>
								                </div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">Select Ward Number</label>
													<select class="form-control" name="wardnum" id="wardnum" onchange="get_mohalla_list(this.value);">
								                         <option value="">--Select Ward Number--</option>
													</select>
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">Select Mohalla Name</label>
													<select class="form-control" name="mohalla" id="mohalla" onchange="get_surveyor_list();">
								                        <option value="">--Select Mohalla Name--</option>
													</select>
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">Select Surveyor</label>
													<select class="form-control" name="surv" id="surv">
								                         <option value="">--Select Surveyor--</option>
													</select>
												</div>
											</div>
											
										</div>
										
									</div>
									<div class="panel-footer text-right">
									
										{!!Form::submit('Assign Ward',array('class'=>'btn btn-danger text-uppercase'))!!}
									
									</div>
								{!!Form::Close()!!}
								<!--===================================================-->
								<!--End Block Styled Form -->
					
							</div>
						</div>
					
					</div>
				</div>
					
			</div>		
					
		
	@endsection
	
	@section('script');
	<script>
		$('document').ready(function(e){
			city();
		});
		function city()
		{
			
			$.ajax
			({
				url:"{{url('/')}}/getnagarpalika",
				dataType:'json',
				success:function(data)
				{
					var msg='<option value="">--Select Nagar Palika--</option>';
					for(var i=0;i<data.length;i++)
					{
						msg=msg+'<option value="'+data[i].city+'">'+data[i].city+'</option>';
					}
					$("#nagarpalika").html(msg);
				}
			});
		}
		function get_ward_number(value)
		{
			
			$.ajax
			({
				url:"{{url('/')}}/getwardnum/"+value,
				dataType:'json',
				success:function(data)
				{
					var msg='<option value="">--Select Ward Number--</option>';
					for(var i=0;i<data.length;i++)
					{
						msg=msg+'<option value="'+data[i].ward_number+'">'+data[i].ward_number+'->'+data[i].ward_name+'->'+data[i].mohalla_name+'</option>';
					}
					$("#wardnum").html(msg);
				}
			});
		}
		function get_mohalla_list(value)
		{
			var nagarpalika=$("#nagarpalika").val();
			$.ajax
			({
				url:"{{url('/')}}/getmohalla/"+value+"/"+nagarpalika,
				dataType:'json',
				success:function(data)
				{
					var msg='<option value="">--Select Mohalla--</option>';
					for(var i=0;i<data.length;i++)
					{
						msg=msg+'<option value="'+data[i].mohalla_name+'">'+data[i].mohalla_name+'</option>';
					}
					$("#mohalla").html(msg);
				}
			});
		}
		function get_surveyor_list()
		{
			var city = $('#nagarpalika').val();
			//alert(city);
			$.ajax
			({
				url:"{{url('/')}}/getSurveyorlist/"+city,
				dataType:'json',
				success:function(data)
				{
					var msg='<option value="">--Select Surveyor--</option>';
					for(var i=0;i<data.length;i++)
					{
						msg=msg+'<option value="'+data[i].id+'">'+data[i].name+'->'+data[i].username+'</option>';
					}
					$("#surv").html(msg);
				}
			});
		}
	</script>

@endsection
			
			

		

		

	
		
		



	
	

