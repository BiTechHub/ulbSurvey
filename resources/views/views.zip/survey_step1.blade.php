   @extends('master')
   @section('content');
       <!--CONTENT CONTAINER-->
       <!--===================================================-->
       <div id="content-container">
           <!--Page Title-->
           <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
           @if (session()->get('user_type') == 'Admin')
               <<form method="post" action="{{ url('/') }}/Search-Survey-Details-List">
                   {{ csrf_field() }}
                   <div id="page-title">
                       <h1 class="page-header text-overflow">Survey Data</h1>
                       <div class="searchbox">
                           <div class="input-group custom-search-form">
                               <input type="text" class="form-control" name="keyword" placeholder="Search Key Word .....">
                               <span class="input-group-btn">
                                   <button class="text-muted" type="submit"><i class="fa fa-search"></i></button>
                               </span>
                           </div>
                       </div>
                   </div>
                   </form>
               @else
                   <div id="page-title">
                       <h1 class="page-header text-overflow">Survey Data</h1>
                   </div>
           @endif
           <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
           <!--End page title-->
           <!--===================================================-->
           <div id="page-content">
               <!-- Basic Data Tables -->
               <!--===================================================-->
               <div class="panel">
                   @if ($errors->any())
                       <div class="alert alert-danger">
                           <ul>
                               @foreach ($errors->all() as $error)
                                   <li>{{ $error }}</li>
                               @endforeach
                           </ul>
                       </div>
                   @endif
                   <div class="panel-body">
                       @if ($user_access[0]->fn_add == 'Y')
                           <div class="row">
                               <div class="col-md-12">
                                   <a href="{{ url('/') }}/Add-New-House" class="btn btn-info pull-right">Add House</a>
                               </div>
                           </div>
                       @endif
                       <div class="table-responsive">
                           <table class="table table-striped table-bordered" cellspacing="0" width="100%">
                               <thead>
                                   <tr>
                                       <th>Sr.no.</th>
                                       <th>House Number</th>
                                       <th>Ward Number</th>
                                       <th>Ward Name</th>
                                       <th>Mohalla Name</th>
                                       <th>Basement</th>
                                       <th>Number Of Floor</th>
                                       <th>House Type</th>
                                       <th>City</th>
                                       <th>Survey By</th>
                                       <th>Action</th>
                                   </tr>
                               </thead>
                               <tbody>
                                   @foreach ($surveydata as $index => $value)
                                       <tr>
                                           <td>{{ ($surveydata->currentpage() - 1) * $surveydata->perpage() + $index + 1 }}
                                           </td>
                                           <td style="display:none">{{ $value->id }}</td>
                                           <td>{{ $value->house_number }}</td>
                                           <td>{{ $value->ward_number }}</td>
                                           <td>{{ $value->ward_name }}</td>
                                           <td>{{ $value->mohalla }}</td>
                                           <td>{{ $value->basement }}</td>
                                           <td>{{ $value->no_of_floor }}</td>
                                           <td>{{ $value->house_type }}</td>
                                           <td>{{ $value->city }}</td>
                                           <td>{{ $value->username }}</td>
                                           <!--<td><img src="{{ url('/') }}/new_gis/upload/{{ $value->image_name }}" ></td>-->
                                           <td><a class="label label-primary" href="#" data-target="#demo-default-modal"
                                                   data-toggle="modal"
                                                   onclick="showImage('{{ url('/') }}/new_gis/upload/{{ $value->image_name }}','{{ $value->id }}')">View</a>
                                               <a class="label label-primary" href="#" data-target="#map-default-modal"
                                                   data-toggle="modal"
                                                   onclick="showMap({{ $value->lat }},{{ $value->lng }})">View On
                                                   Map</a>
                                               @if ($user_access[0]->fn_update == 'Y')
                                                   <a class="label label-success" href="#"
                                                       onclick="confirmData('{{ $value->id }}');">Verify</a>
                                                   <a class="label label-danger" href="#"
                                                       onclick="RejectDatat('{{ $value->id }}');">Reject</a>
                                                   <a class="label label-info"
                                                       href="{{ url('/') }}/View-Update-Newhouse?id={{ $value->id }}">Edit</a>
                                                   <a class="label label-info"
                                                       href="{{ url('/') }}/Update-Image/{{ $value->id }}">Change
                                                       Image</a>
                                                   @if ($user_access[0]->fn_delete == 'Y')
                                                       <form method="post" id="delete_form_{{ $value->id }}"
                                                           action="{{ url('/') }}/Delete-House">
                                                           {{ csrf_field() }}
                                                           <input type="hidden" name="deleted_id"
                                                               value="{{ $value->id }}">
                                                           <a onclick="deleteRow('{{ $value->id }}')" type="button"
                                                               class="label label-danger"
                                                               title="Click to delete this row">Delete</a>
                                                       </form>
                                                   @endif
                                           </td>
                                   @endif
                                   </tr>
                                   @endforeach
                               </tbody>
                           </table>
                       </div>
                       {{ $surveydata->links() }}
                   </div>
               </div>
               <!--===================================================-->
               <!-- End Striped Table -->
           </div>
       </div>
       <div class="modal fade" id="demo-default-modal" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal"
           aria-hidden="true">
           <div class="modal-dialog">
               <div class="modal-content">
                   <!--Modal header-->
                   <div class="modal-header">
                       <button data-dismiss="modal" class="close" type="button">
                           <span aria-hidden="true">&times;</span>
                       </button>
                       <h4 class="modal-title"><span id="address">House Picture</span>
                           <a id="anticlock" href="javascript:RotateAntiClockwise();"><i class="fa fa-rotate-left"
                                   aria-hidden="true"></i></a>
                           <a id="clock" href="javascript:RotateClockwise();"><i class="fa fa-rotate-right"
                                   aria-hidden="true"></i></a>
                       </h4>
                   </div>
                   <!--Modal body-->
                   <div class="modal-body">
                       <img src="img/av1.png" id="image" style="width:100%;height:450px">
                   </div>
                   <!--Modal footer-->
                   <div class="modal-footer">
                       <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                   </div>
               </div>
           </div>
       </div>
       <div class="modal fade" id="map-default-modal" role="dialog" tabindex="-1" aria-labelledby="map-default-modal"
           aria-hidden="true">
           <div class="modal-dialog">
               <div class="modal-content">
                   <!--Modal header-->
                   <div class="modal-header">
                       <button data-dismiss="modal" class="close" type="button">
                           <span aria-hidden="true">&times;</span>
                       </button>
                       <h4 class="modal-title"><span id="address">Map View</span></h4>
                   </div>
                   <!--Modal body-->
                   <div class="modal-body">
                       <div style="height:500px;width:100%;" id="map"></div>
                   </div>
                   <!--Modal footer-->
                   <div class="modal-footer">
                       <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                   </div>
               </div>
           </div>
       </div>
       <!--===================================================-->
       <!--End page content-->
   @endsection
   @section('script')
       <script>
           function showImage(imageName, id) {
               $("#image").attr('src', imageName);
               $("#clock").attr('href', "javascript:RotateClockwise('" + id + "');");
               $("#anticlock").attr('href', "javascript:RotateAntiClockwise('" + id + "');");
           }

           function showMap(lat1, lng1) {
               var myLatLng = {
                   lat: lat1,
                   lng: lng1
               };
               initMap(myLatLng);
           }

           function initMap(myLatLng) {
               var map = new google.maps.Map(document.getElementById('map'), {
                   zoom: 20,
                   center: myLatLng,
                   mapTypeId: 'satellite'
               });
               var marker = new google.maps.Marker({
                   position: myLatLng,
                   map: map,
                   title: 'Hello World!'
               });
           }

           function confirmData(id) {
               //alert(id);
               var flag = confirm('Are you sure to verify this data ?');
               if (flag) {
                   var url = "{{ url('/') }}/verify?id=" + id;
                   window.location.assign(url);
               }
           }

           function RejectDatat(id) {
               //alert(id);
               swal("Write Rejection Reason here:", {
                       content: "input",
                   })
                   .then((value) => {
                       var url = "{{ url('/') }}/RejectedSurveyData?id=" + id + "&reason=" + value;
                       //alert(url);
                       window.location.assign(url);
                   });
           }

           function RotateClockwise(id) {
               //alert(id);
               var flag = confirm('Are you sure want to rotate this photo ?');
               if (flag) {
                   var url = "{{ url('/') }}/RotateClockwise/" + id;
                   window.location.assign(url);
               }
           }

           function RotateAntiClockwise(id) {
               //alert(id);
               var flag = confirm('Are you sure want to rotate this photo ?');
               if (flag) {
                   var url = "{{ url('/') }}/RotateAntiClockwise/" + id;
                   window.location.assign(url);
               }
           }

           function deleteRow(id) {
               swal({
                       title: "Are you sure?",
                       text: "Once deleted, you will not be able to recover this house!",
                       icon: "warning",
                       buttons: true,
                       dangerMode: true,
                   })
                   .then((willDelete) => {
                       if (willDelete) {
                           $("#delete_form_" + id).submit();
                       } else {
                           swal("Your data is safe!");
                       }
                   });
           }
       </script>
   @endsection
