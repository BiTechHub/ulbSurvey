			@extends('master')
			@section('content');
			
			<!--CONTENT CONTAINER-->
				<!--===================================================-->
				<div id="content-container">
					
					<!--Page Title-->
					<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
					<div id="page-title">
						<h1 class="page-header text-overflow">Mange User</h1>

						
						
					</div>
					<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
					<!--End page title-->

					
			<!--===================================================-->
				<div id="page-content">
					
					<!-- Basic Data Tables -->
					<!--===================================================-->
					<div class="panel">
						<div class="panel-body">
						@if($user_access[0]->fn_add=='Y')
						  <div align="right">
							       <a href="{{url('/')}}/createUser" class="btn btn-info" role="button">Create User</a>
							</div>
						@endif
						  <div class="table-responsive">
							<table class="table table-striped table-bordered " cellspacing="0" width="100%" data-toggle="table">
								<thead>
									<tr>
									    <th>Sr.No.</th>
										<th>Name</th>
										<th>Contact</th>
										<th>User name</th>
										<th>Password</th>
										<th>User Type</th>
										 <th>ULB</th>
										 <th>Ward Number</th>
										 <th>Ward Name</th>
										 <th>Mohalla Name</th>
										 <th>Action</th>
									</tr>
								</thead>
								<tbody>
								   <?php $a = 1; ?>
									@foreach($userslist as $value)
									
									<tr>
									    <td>{{$a}}</td>
										<td>{{$value->name}}</td>
										<td>{{$value->contact}}</td>
										<td>{{$value->username}}</td>
										<td>{{$value->password}}</td>
										<td>{{$value->user_type}}</td>
										<td>{{$value->city}}</td>
										<td>{{$value->ward_no}}</td>
										<td>{{$value->ward_name}}</td>
										<td>{{$value->mohalla}}</td>
										<td>
										@if($user_access[0]->fn_delete=='Y')
										<a class="label label-danger" href="#">Delete</a>
										@endif
										@if($user_access[0]->fn_update=='Y')
										<a href="{{url('/')}}/updateUser/{{$value->id}}" class="label label-success">Edit</a>
										@if($value->status=='Active')
										<a href="#" onclick="confirminActive('{{$value->id}}&status=In-Active');" class="label label-success" title="click here to In-Active user">Active</a>
										@endif
										@if($value->status=='In-Active')
											<a href="#" onclick="confirmActive('{{$value->id}}&status=Active');" class="label label-danger" title="click here to Active user">In-Active</a>
										@endif
										@endif
										</td>
										<?php $a++; ?>
									</tr>
									
									@endforeach
								</tbody>
							</table>
						</div>
						</div>
					</div>
					<!--===================================================-->
					<!-- End Striped Table -->
					
				</div>
				</div>
				<!--===================================================-->
				<!--End page content-->
			@endsection
            @section('script')
			<script>
			function confirmActive(id)
			{
				
				var flag=confirm('Are you sure want to active this user?');
				if(flag)
				{
					var url="{{url('/')}}/updateUserStatus?id="+id;
					window.location.assign(url);
				}
			}
			function confirminActive(id)
			{
				
				var flag=confirm('Are you sure want to In-active this user?');
				if(flag)
				{
					var url="{{url('/')}}/updateUserStatus?id="+id;
					window.location.assign(url);
				}
			}
			
			</script>
			
			@endsection