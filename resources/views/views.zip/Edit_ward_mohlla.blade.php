
@extends('master')
@section('content');


			<!--CONTENT CONTAINER-->
			<!--===================================================-->
			<div id="content-container">


				<div id="page-content">


					<div class="row">
						<div class="col-sm-12">
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Add Ward/Mohlla</h3>
								</div>

								<!--Block Styled Form -->
								<!--===================================================-->
								{!!Form::Open(array('route'=>'update.WardDetail'))!!}
									<div class="panel-body">
										<div class="row">
										    <div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">NagarPalika</label>
													<select class="form-control" name="ngrpalika" id="nagarpalika" onmouseover="city();">
													    <option value="{{$wardl_data[0]->nagarpalika}}">{{$wardl_data[0]->nagarpalika}}</option>



								                    </select>
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">Ward Number</label>
													<select class="form-control" name="wardnum">
													     <option value="{{$wardl_data[0]->ward_number}}">{{$wardl_data[0]->ward_number}}</option>
								                         <option value="">--Select Ward Number--</option>
														 @for($i=1;$i<=30;$i++)
								                         <option value="{{$i}}">{{$i}}</option>
													 @endfor
								                    </select>
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">Ward Name</label>
													{!!Form::text('wardnam',$wardl_data[0]->ward_name,array('class'=>'form-control','placeholder'=>'Enter Ward name'))!!}
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">Mohlla Name</label>
													{!!Form::text('mohlla',$wardl_data[0]->mohalla_name,array('class'=>'form-control','placeholder'=>'Enter Mohlla name'))!!}
													{!!Form::text('id',$wardl_data[0]->id,array('class'=>'form-control','placeholder'=>'Enter Mohlla name' , 'style'=>'display:none;'))!!}
												</div>
											</div>
										</div>

									</div>
									<div class="panel-footer text-right">
										@if($user_access[0]->fn_update=='Y')
										{!!Form::submit('Update',array('class'=>'btn btn-danger text-uppercase'))!!}
										@endif
									</div>
								{!!Form::Close()!!}
								<!--===================================================-->
								<!--End Block Styled Form -->

							</div>
						</div>

					</div>
				</div>

			</div>


@endsection

@section('script')
<script>
		function city()
		{

			$.ajax
			({
				url:"{{url('/')}}/getnagarpalika",
				dataType:'json',
				success:function(data)
				{
					var msg='<option value="">--Select Nagar Palika--</option>';
					for(var i=0;i<data.length;i++)
					{
						msg=msg+'<option value="'+data[i].city+'">'+data[i].city+'</option>';
					}
					$("#nagarpalika").html(msg);
				}
			});
		}
	</script>
	@endsection















