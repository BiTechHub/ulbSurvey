			@extends('master')
			@section('content');
			
			<!--CONTENT CONTAINER-->
				<!--===================================================-->
				<div id="content-container">
					
					<!--Page Title-->
					<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
					<div id="page-title">
						<h1 class="page-header text-overflow">Rejected Personal Data</h1>

						
						
					</div>
					<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
					<!--End page title-->

					
			<!--===================================================-->
				<div id="page-content">
					<div class="panel">
					  <div class="panel-body">
					  	<form method="POST" action="{{url('/')}}/SearchPersonalDetailsList">
					  		{{csrf_field()}}
					      <div class="row">
								<div class="col-sm-3">
									<div class="form-group">
										<select class="form-control" name="nagar_palika" id="nagarpalika" required="required">
									
											<option value="">--Select Nagar Palika--</option>
										
											
									
										</select>
									</div>
							  </div>
							  <div class="col-sm-3">
									<div class="form-group">
										<select class="form-control" name="ward_number" id="ward_number" >
									
											<option value="">--Select Ward Number --</option>
										
											<option value=""></option>
											@for($i=1;$i<=30;$i++)
												<option value="{{$i}}">{{$i}}</option>
											@endfor
									
										</select>
									</div>
							  </div>
						      <div class="col-sm-3">
							      <div class="form-group">
									 <input type="text" class="form-control" id="housenumber" name="house_number" placeholder="Enter House Number">	
									 <input type="hidden" class="form-control" name="search_type" value="Rejected">	
									
									</div>
							  </div>
							  
							  <div class="col-sm-2">
							        
									<input class="btn btn-success text-uppercase" type="submit" value="search" id="search" name="search" >
									
										
								  
							    </div>
							 
						  </div>
						</form>
					  </div>
					</div>
					<!-- Basic Data Tables -->
					<!--===================================================-->
					<div class="panel">
						<div class="panel-body">
						  <div class="table-responsive">
							<table class="table table-striped table-bordered" cellspacing="0" width="100%">
								<thead>
									<tr>
										<th>Sr.no.</th>
										
										<th>House Number</th>
										<th>Owener Name</th>
										<th>Father Name</th>
										<th>Mobile Number</th>
										<th>Rented Person</th>
										<th>Rented Person Name</th>
										<th>Total Area</th>
										<th>Constructed Area</th>
										<th>Business Area</th>
										<th>Number Of Floor</th>
										<th>Number Of Room</th>
										<th>Basement Area</th>
										<th>Ground Area</th>
										<th>Area of First Floor</th>
										<th>Area of Second Floor</th>
										
										<th>Area of Third Floor</th>
										<th>Length From East</th>
										<th>Length From West</th>
										<th>Length From North</th>
										<th>Length From South</th>
										<th>Localty From East</th>
										<th>Localty From West</th>
										<th>Localty From North</th>
										<th>Localty From South</th>
										<th>Nirman Varsh</th>
										<th>Sadak Ki Chaudai</th>
										<th>Nirman Ki Prakriti</th>
										<th>Farsh Ki Prakriti</th>
										<th>Status</th>

										<th>Varyfied</th>
										<th>Action</th>
										
										 
									</tr>
								</thead>
								<tbody>
									@foreach($surveydata as $index=>$value)
									<tr>
										<td>
										@if($user_access[0]->fn_update=='Y')
										<a target="_BLANK" class="label label-primary" href="{{url('/')}}/UpdateDetails?id={{$value->survey_id}}" >{{($surveydata->currentpage()-1) * $surveydata->perpage() + $index + 1 }}<a>
										@else
											{{($surveydata->currentpage()-1) * $surveydata->perpage() + $index + 1 }}
										@endif
										</td>
									    <td style="display:none">{{$value->survey_id}}</td>
										<td style="display:none">{{$value->survey_id}}</td>
										<td>{{$value->house_number}}</td>
										<td>{{$value->name}}</td>
										<td>{{$value->father_name}}</td>
										<td>{{$value->mobile_number}}</td>
										<td>{{$value->rented_person}}</td>
										<td>{{$value->rented_person_name}}</td>
										<td>{{$value->area_all}}X{{$value->area_all_width}}</td>
										<td>{{$value->area_constructed}}X{{$value->area_constructed_width}}</td>
										<td>{{$value->area_business}}X{{$value->area_business_width}}</td>
										<td>{{$value->no_of_floor}}</td>
										<td>{{$value->no_of_room}}</td>
										<td>{{$value->basement_area}}X{{$value->basement_area_width}}</td>
										<td>{{$value->ground_area}}X{{$value->ground_area_width}}</td>
										<td>{{$value->first_area}}X{{$value->first_area_width}}</td>
										<td>{{$value->second_area}}X{{$value->second_area_width}}</td>
										<td>{{$value->third_area}}X{{$value->third_area_width}}</td>
										<td>{{$value->length_east}}</td>
										<td>{{$value->length_west}}</td>
										<td>{{$value->length_north}}</td>
										<td>{{$value->length_south}}</td>
										<td>{{$value->locality_east}}</td>
										<td>{{$value->locality_west}}</td>
										<td>{{$value->locality_north}}</td>
										<td>{{$value->locality_south}}</td>
										
										<td>{{$value->nirmanVarsh}}</td>
										<td>{{$value->sadakKichoudai}}</td>
										<td>{{$value->NirmanPrakriti}}</td>
										<td>{{$value->FarshPrakriti}}</td>
										<td>{{$value->status}}</td>
										<td>{{$value->DataVerified}}</td>
										<td>
										@if($user_access[0]->fn_update=='Y')
										<a target="_BLANK" class="label label-primary" href="{{url('/')}}/UpdateDetails?id={{$value->survey_id}}" >Edit</a> 
										
										@endif
										</td>
										
										
										
										
										
									</tr>
									@endforeach
								</tbody>
							</table>
							</div>
							{{$surveydata->links()}}
						</div>
					</div>
					<!--===================================================-->
					<!-- End Striped Table -->
					
				</div>
				</div>
	
	
				<!--===================================================-->
				<!--End page content-->
			@endsection

			@section('script')
			<script>
			

		$('document').ready(function(e){
				city();
			});
			function city()
			{
				
				$.ajax
				({
					url:"{{url('/')}}/getnagarpalika",
					dataType:'json',
					success:function(data)
					{
						var msg='<option value="">--Select Nagar Palika--</option>';
						for(var i=0;i<data.length;i++)
						{
							msg=msg+'<option value="'+data[i].city+'">'+data[i].city+'</option>';
						}
						$("#nagarpalika").html(msg);
					}
				});
			}
		</script>
			
	@endsection

			