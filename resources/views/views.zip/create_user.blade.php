		@extends('master')
		@section('content')
			<!--CONTENT CONTAINER-->
				<!--===================================================-->
				<div id="content-container">
					
					<!--Page Title-->
					<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
					<div id="page-title">
						<h1 class="page-header text-overflow">Create User</h1>

						
						
					</div>
					<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
					<!--End page title-->

					<!--Page content-->
					<!--===================================================-->
					<div id="page-content">
						
					
						<div class="row">
							
								<div class="panel">
									
						
									
									{!!Form::Open(array('route'=>'admin.saveUser','files'=>true))!!}
										<div class="panel-body">
											@if ($errors->any())
								                  <div class="alert alert-danger">
								                      <ul>
								                          @foreach ($errors->all() as $error)
								                              <li>{{ $error }}</li>
								                          @endforeach
								                      </ul>
								                  </div>
								              @endif
											<div class="row">
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Select User Type</label>
														<select class="form-control" name="user_type">
														  <option value=''>--Select User Type--</option>
														  <option value="Admin">Admin</option>
														  <option value="Surveyor">Surveyor</option>
														  <option value="DEO">Data Entry Operator</option>
														  <option value="District Admin">District Admin</option>
														  <option value="Parivar Surveyor">Parivar Surveyor</option>
														</select>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Select State</label>
														<select class="form-control" name="state" onchange="city_by_state(this.value);">
														<option value=''>--Select State--</option>
															@foreach($statelist as $value)
																<option value='{{ $value->id }}'>{{ $value->state }}</option>
															@endforeach
														</select>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Select City</label>
														<select class="form-control" id="city" name="city">
															
															
															
														</select>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Name</label>
														{!!Form::text('name','',array('class'=>'form-control','placeholder'=>'Enter  Name'))!!}
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Mobile</label>
														{!!Form::number('mobile','',array('class'=>'form-control','placeholder'=>'Enter  Name'))!!}
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">User Name</label>
														{!!Form::text('user_name','',array('class'=>'form-control','placeholder'=>'Enter  Name'))!!}
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Password</label>
														{!!Form::password('password',array('class'=>'form-control','placeholder'=>'Enter  Name'))!!}
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">E-mail Address</label>
														{!!Form::text('email','',array('class'=>'form-control','placeholder'=>'Enter  Name'))!!}
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Address</label>
														{!!Form::text('address','',array('class'=>'form-control','placeholder'=>'Enter  Name'))!!}
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Login Type</label>
														<select class="form-control" name="login_type">
														  <option value=''>--Select Login Type--</option>
														  <option value="Offline">Offline</option>
														  <option value="Online">Online</option>
														</select>
													</div>
												</div>
											</div>
										</div>
										<div class="panel-footer text-right">
										@if($user_access[0]->fn_add=='Y')
											{!!Form::submit('Create User',array('class'=>'btn btn-success text-uppercase'))!!}
										@endif
										</div>
									{!!Form::Close()!!}
									<!--===================================================-->
									<!--End Block Styled Form -->
						
								</div>
							
							
						</div>
						
					</div>
					<!--===================================================-->
					<!--End page content-->


				</div>
				
				<!--===================================================-->
				<!--END CONTENT CONTAINER-->
            @endsection
			@section('script')
			<script>
				function city_by_state(value)
				{
					$.ajax
					({
						url:"{{url('/')}}/getcity/"+value,
						dataType:'json',
						success:function(data)
						{
							var msg='<option value="">--Select City--</option>';
							for(var i=0;i<data.length;i++)
							{
								msg=msg+'<option value="'+data[i].city+'">'+data[i].city+'</option>';
							}
							$("#city").html(msg);
						}
					});
				}
				</script>
				@endsection