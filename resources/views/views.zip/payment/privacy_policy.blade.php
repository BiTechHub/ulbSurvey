@extends('payment.master')
@section('content')

  <section class="container-fluid">

    <h3>PRIVACY STATEMENT</h3>

		<h5>1 - WHAT DO WE DO WITH YOUR INFORMATION?</h5>

		When you pay tax , we collect the personal information you give us such as your name, address and email address.

		<br><br>
		When you browse our site, we also automatically receive your computer’s internet protocol (IP) address in order to provide us with information that helps us learn about your browser and operating system.

		<br><br>
		Email marketing (if applicable): With your permission, we may send you emails about our updates.




		<h5>2 - CONSENT</h5>




		How do you get my consent?
		<br><br>

		When you provide us with personal information to complete a transaction, verify your credit card, pay your tax, we imply that you consent to our collecting it and using it for that specific reason only.

		<br><br>
		If we ask for your personal information for a secondary reason, like marketing, we will either ask you directly for your expressed consent, or provide you with an opportunity to say no.

		<br><br>


		How do I withdraw my consent?

		<br><br>
		If after you opt-in, you change your mind, you may withdraw your consent for us to contact you, for the continued collection, use or disclosure of your information, at anytime, by contacting us at <b>nppsitapur@gmail.com</b> or mailing us at: WARD NO 9 Nagar Palika Parishad Sitapur

		<br><br>

		<h5>3 - DISCLOSURE</h5>




		We may disclose your personal information if we are required by law to do so or if you violate our Terms of Service.


		<br><br>


		<h5>4 - THIRD-PARTY SERVICES</h5>




		In general, the third-party providers used by us will only collect, use and disclose your information to the extent necessary to allow them to perform the services they provide to us.
		<br><br>

		However, certain third-party service providers, such as payment gateways and other payment transaction processors, have their own privacy policies in respect to the information we are required to provide to them for your purchase-related transactions.

		<br><br>
		For these providers, we recommend that you read their privacy policies so you can understand the manner in which your personal information will be handled by these providers.
		<br><br>

		In particular, remember that certain providers may be located in or have facilities that are located a different jurisdiction than either you or us. So if you elect to proceed with a transaction that involves the services of a third-party service provider, then your information may become subject to the laws of the jurisdiction(s) in which that service provider or its facilities are located.
		<br><br>

		Once you leave our website or are redirected to a third-party website or application, you are no longer governed by this Privacy Policy or our website’s Terms of Service.

		<br><br>
		Links

		<br><br>
		When you click on links on our website, they may direct you away from our site. We are not responsible for the privacy practices of other sites and encourage you to read their privacy statements.

		<br><br>
		<h5> 5 - SECURITY</h5>




		To protect your personal information, we take reasonable precautions and follow industry best practices to make sure it is not inappropriately lost, misused, accessed, disclosed, altered or destroyed.

		<br><br>

		<h5> 6 - COOKIES</h5>


		We use cookies to maintain session of your user. It is not used to personally identify you on other websites.

		<br><br>


		<h5> 8 - AGE OF CONSENT</h5>




		 By using this site, you represent that you are at least the age of majority in your state or province of residence, or that you are the age of majority in your state or province of residence and you have given us your consent to allow any of your minor dependents to use this site.


		<br><br>

		<h5> 9 - CHANGES TO THIS PRIVACY POLICY</h5>




		We reserve the right to modify this privacy policy at any time, so please review it frequently. Changes and clarifications will take effect immediately upon their posting on the website. If we make material changes to this policy, we will notify you here that it has been updated, so that you are aware of what information we collect, how we use it, and under what circumstances, if any, we use and/or disclose it.

		<br><br>
		If our store is acquired or merged with another company, your information may be transferred to the new owners so that we may continue to sell products to you.


		<br><br>

		QUESTIONS AND CONTACT INFORMATION


		<br><br>

		If you would like to: access, correct, amend or delete any personal information we have about you, register a complaint, or simply want more information contact our Privacy Compliance Officer at <b>nppsitapur@gmail.com</b> or mailing us at: WARD NO 9 Nagar Palika Parishad Sitapur

		<br><br>
		[Re: Privacy Compliance Officer]

  </section>

@endsection
