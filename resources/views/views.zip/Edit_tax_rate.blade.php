@extends('master')
@section('content');
    <!--CONTENT CONTAINER-->
    <!--===================================================-->
    <div id="content-container">
        <div id="page-content">
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Edit Tax Rate</h3>
                        </div>
                        <!--Block Styled Form -->
                        <!--===================================================-->
                        {!! Form::Open(['route' => 'update.TaxRateDetail']) !!}
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-2">
                                <div class="form-group">
                                    <label class="control-label">Nagar Palika</label>
                                    <select class="form-control" name="ngrpalika" id="nagarpalika" onchange="get_ward_number(this.value)" required>
                                        <option value="">--Select Nagar Palika--</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label class="control-label">Ward Number</label>
                                    <select class="form-control" name="wardno" id="ward_number" required onchange="GetRoadwidth()">
                            <option value="">--Select Ward Number--</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label class="control-label">Bahvan Ka Prakar</label>
                                    <select class="form-control" name="buildingtype" id="bhavan_parkar" onchange="get_surveyor_list();" required>
                                         <option value="">--Select--</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label class="control-label">Sadak Ki Chaudai</label>
                                    <select class="form-control" name="roadtype" id="sadak_chaudai" required>
                                         <option value="">--Select--</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label class="control-label">Rate</label>
                                    {!!Form::text('rate',$tax_data[0]->rate,array('class'=>'form-control','placeholder'=>'Enter Rate','required'))!!}
                                    {!!Form::text('id',$tax_data[0]->id,array('class'=>'form-control','placeholder'=>'Enter Rate' , 'style'=>'display:none;'))!!}
                                </div>
                            </div>


                            </div>
                        </div>
                        <div class="panel-footer text-right">
                            @if($user_access[0]->fn_update=='Y')
                            {!!Form::submit('Update',array('class'=>'btn btn-danger text-uppercase'))!!}
                            @endif
                        </div>
                      {!!Form::Close()!!}
                        <!--===================================================-->
                        <!--End Block Styled Form -->
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('script')
<script>
    $('document').ready(function(e){
        city();
    });
    function city()
    {
        var oldData="{{$tax_data[0]->city}}";
        $.ajax
        ({
            url:"{{url('/')}}/getnagarpalika",
            dataType:'json',
            success:function(data)
            {
                var msg='<option value="">--Select Nagar Palika--</option>';
                for(var i=0;i<data.length;i++)
                {
                    if(oldData==data[i].city)
                    {
                        msg=msg+'<option selected value="'+data[i].city+'">'+data[i].city+'</option>';
                    }
                    else{
                        msg=msg+'<option value="'+data[i].city+'">'+data[i].city+'</option>';
                    }

                }
                $("#nagarpalika").html(msg);
                get_ward_number();
            }
        });
    }
    function get_ward_number()
    {
        var nagarpalika=$("#nagarpalika").val();
        var olddatavalue = "{{$tax_data[0]->ward_number}}";
        $.ajax
        ({
            url:"{{url('/')}}/getwardnum/"+nagarpalika,
            dataType:'json',
            success:function(data)
            {
                var msg='<option value="">--Select Ward Number--</option>';
                for(var i=0;i<data.length;i++)
                {
                    if(olddatavalue==data[i].id){
                        msg=msg+'<option selected value="'+data[i].id+'">'+data[i].ward_number+'->'+data[i].ward_name+'->'+data[i].mohalla_name+'</option>';
                    }
                    else{
                        msg=msg+'<option value="'+data[i].id+'">'+data[i].ward_number+'->'+data[i].ward_name+'->'+data[i].mohalla_name+'</option>';
                    }

                }
                $("#ward_number").html(msg);
                GetRoadwidth();
            }
        });
    }


$.ajax({
    url:"{{url('/')}}/new_gis/bpage.php?action=selectHouseDetails",
    dataType:"json",
    success:function(data){
        console.log(data);

        var NirmanPrakriti=data.NirmanPrakriti;
        var olddata = "{{$tax_data[0]->bhawan_ka_prakar}}";
        $("#bhavan_parkar").html();
        for(var i=1;i<NirmanPrakriti.length;i++)
        {
            if(olddata==NirmanPrakriti[i])
            {
                $("#bhavan_parkar").append('<option selected value="'+NirmanPrakriti[i]+'">'+NirmanPrakriti[i]+'</option>');
            }
            else{
                $("#bhavan_parkar").append('<option  value="'+NirmanPrakriti[i]+'">'+NirmanPrakriti[i]+'</option>');
            }

        }
        var FarshPrakriti=data.FarshPrakriti;
        $("#farsh_prakar").html();
        for(var i=1;i<FarshPrakriti.length;i++)
        {
            $("#farsh_prakar").append('<option value="'+FarshPrakriti[i]+'">'+FarshPrakriti[i]+'</option>');
        }
    }
});
function GetRoadwidth()
{

    var city=$("#nagarpalika").val();
    var olddatavalue = "{{$tax_data[0]->sadak_ki_choudai}}";
    //alert(city);
    $.ajax({
        url:"{{url('/')}}/get-Road-width/"+city,
        dataType:"json",
        success:function(data)
        {
            var msg='<option value="">--Select--</option>';
            for(var i=0;i<data.length;i++)
            {
                if(olddatavalue==data[i].road_width)
                {
                    msg=msg+'<option selected value="'+data[i].road_width+'">'+data[i].road_width+'</option>';
                }
                else{
                    msg=msg+'<option value="'+data[i].road_width+'">'+data[i].road_width+'</option>';
                }

            }
            $("#sadak_chaudai").html(msg);
        }
    });
}
function deleteRow(id) {
           swal({
                   title: "Are you sure?",
                   text: "Once deleted, you will not be able to recover this imaginary file!",
                   icon: "warning",
                   buttons: true,
                   dangerMode: true,
               })
               .then((willDelete) => {
                   if (willDelete) {
                       $("#delete_form_" + id).submit();
                   } else {
                       swal("Your data is safe!");
                   }
               });
       }
</script>

@endsection
