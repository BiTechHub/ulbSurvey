		@extends('master')
		@section('content')
		<!--CONTENT CONTAINER-->
			<!--===================================================-->
			<div id="content-container">
				
				<!--Page Title-->
				<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
				<div id="page-title">
					<h1 class="page-header text-overflow">Dashboard</h1>

					<!--Searchbox-->
					
				</div>
				
				<ol class="breadcrumb">
					<li><a href="#">Dashboard</a></li>
					
				</ol>
				<div class="row">
					{!!Form::Open(array('route'=>'dash.board'))!!}
						<div class="col-xs-offset-3 col-xs-6 col-md-offset-4 col-md-3">
							<div class="form-group">
								<select class="form-control" name="ngpalika" id="nagarpalika">
									
									<option value="">--Select Ward Number--</option>
									
									<option value=""></option>
									
								</select>
							</div>
						</div>
							<div class="col-md-2">
								
									
									{!!Form::submit('View',array('class'=>'btn btn-danger text-uppercase'))!!}
									
								
							</div>
					{!!Form::Close()!!}
				</div>
				<div id="page-content">
				    <div class="row">
						<div class="col-lg-12">
					
							<div class="row">
					            @if($dashboardMenuData)
								@if($dashboardMenuData['New House Details Not-Verified']=='Y')
								<div class="col-md-3">
									<div class="panel panel-primary panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_survey_today}}</span>
											<p>Today Total New House</p>
											{{$total_survey_today}}/{{$total_survey}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['New House Details Verified']=='Y')
								<div class="col-md-3">
									<div class="panel panel-success panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_verify_house_data_today}}</span>
											<p>Today Verified New House</p>
											{{$total_verify_house_data_today}}/{{$total_verify_house_data}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['New House Details Not-Verified']=='Y')
								<div class="col-md-3">
									<div class="panel panel-warning panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_unverify_house_data_today}}</span>
											<p>Today Unverified New House</p>
											{{$total_unverify_house_data_today}}/{{$total_unverify_house_data}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['New House Details Rejected']=='Y')
								<div class="col-md-3">
									<div class="panel panel-danger panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_rejected_house_data_today}}</span>
											<p>Today Rejected New House</p>
											{{$total_rejected_house_data_today}}/{{$total_rejected_house_data}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['Personal Details Not-Verified']=='Y')
								
								
								<div class="col-md-3">
									<div class="panel panel-primary panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_personal_detail_today}}</span>
											<p>Today Total Personal Details</p>
											{{$total_personal_detail_today}}/{{$total_personal_data}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['Personal Details Verified']=='Y')
								<div class="col-md-3">
									<div class="panel panel-success panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_verify_personal_data_today}}</span>
											<p>Today Verified Personal Details</p>
											{{$total_verify_personal_data_today}}/{{$total_verify_personal_data}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['Personal Details Not-Verified']=='Y')
								<div class="col-md-3">
									<div class="panel panel-warning panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_unverify_personal_data_today}}</span>
											<p>Today Unverified Personal Details</p>
											{{$total_unverify_personal_data_today}}/{{$total_unverify_personal_data}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['Personal Details Rejected']=='Y')
								<div class="col-md-3">
									<div class="panel panel-danger panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_rejected_personal_data_today}}</span>
											<p>Today Rejected Personal Details</p>
											{{$total_rejected_personal_data_today}}/{{$total_rejected_personal_data}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['Other House Details Not-Verified']=='Y')
								
								
					
								
								<div class="col-md-3">
									<div class="panel panel-primary panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_house_detail_today}}</span>
											<p>Today Total House Details</p>
											{{$total_house_detail_today}}/{{$total_house_data}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['Other House Details Verified']=='Y')
								<div class="col-md-3">
									<div class="panel panel-success panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_verify_house_detail_today}}</span>
											<p>Today Verified House Details</p>
											{{$total_verify_house_detail_today}}/{{$total_verify_house_detail}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['Other House Details Not-Verified']=='Y')
								<div class="col-md-3">
									<div class="panel panel-warning panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_unverify_house_detail_today}}</span>
											<p>Today Unverified House Details</p>
											{{$total_unverify_house_detail_today}}/{{$total_unverify_house_detail}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['Other House Details Rejected']=='Y')
								<div class="col-md-3">
									<div class="panel panel-danger panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_rejected_house_detail_today}}</span>
											<p>Today Rejected House Details</p>
											{{$total_rejected_house_detail_today}}/{{$total_rejected_house_detail}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['Assets Details Not-Verified']=='Y')
								
								
					
								
								<div class="col-md-3">
									<div class="panel panel-primary panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_asstes_today}}</span>
											<p>Today Total Assets</p>
											{{$total_asstes_today}}/{{$total_asstes}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['Assets Details Verified']=='Y')
								<div class="col-md-3">
									<div class="panel panel-success panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_asstes_verify_today}}</span>
											<p>Today Verified Assets</p>
											{{$total_asstes_verify_today}}/{{$total_asstes_verify}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['Assets Details Not-Verified']=='Y')
								<div class="col-md-3">
									<div class="panel panel-warning panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_asstes_unverify_today}}</span>
											<p>Today Unverified Assets</p>
											{{$total_asstes_unverify_today}}/{{$total_asstes_unverify}}
										</div>
									</div>
								</div>
								@endif
								@if($dashboardMenuData['Assets Details Rejected']=='Y')
								<div class="col-md-3">
									<div class="panel panel-danger panel-colorful">
										<div class="pad-all text-center">
											<span class="text-5x text-thin">{{$total_asstes_rejected_today}}</span>
											<p>Today Rejected Assets</p>
											{{$total_asstes_rejected_today}}/{{$total_asstes_reject}}
										</div>
									</div>
								</div>
								@endif
								@endif
								
					
							</div>
						</div>		
					</div>
				</div>
			</div>
		
	@endsection
	@section('script');
		<script>
			$('document').ready(function(e){
			city();
			});
			function city()
			{
				
				$.ajax
				({
					url:"{{url('/')}}/getnagarpalika",
					dataType:'json',
					success:function(data)
					{
						var msg='<option value="">--Select Nagar Palika--</option>';
						for(var i=0;i<data.length;i++)
						{
							msg=msg+'<option value="'+data[i].city+'">'+data[i].city+'</option>';
						}
						$("#nagarpalika").html(msg);
					}
				});
			}
		</script>
	@endsection