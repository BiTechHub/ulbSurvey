
@extends('master')
@section('content');


			<!--CONTENT CONTAINER-->
			<!--===================================================-->
			<div id="content-container">


				<div id="page-content">
					@if($user_access[0]->fn_add=='Y')
				   <div class="row">
						<div class="col-sm-12">
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Manage Tax Rate</h3>
								</div>

								<!--Block Styled Form -->
								<!--===================================================-->
								{!!Form::Open(array('route'=>'save.TaxRate'))!!}
									<div class="panel-body">
										<div class="row">
										  <div class="col-sm-2">
												<div class="form-group">
													<label class="control-label">Nagar Palika</label>
													<select class="form-control" name="ngrpalika" id="nagarpalika" onchange="get_ward_number(this.value)" required>
								                        <option value="">--Select Nagar Palika--</option>
													</select>
								                </div>
											</div>
											<div class="col-sm-2">
												<div class="form-group">
													<label class="control-label">Ward Number</label>
													<select class="form-control" name="ward_number" id="ward_number" required onchange="GetRoadwidth()">
								            <option value="">--Select Ward Number--</option>
													</select>
								                </div>
											</div>
											<div class="col-sm-2">
												<div class="form-group">
													<label class="control-label">Bahvan Ka Prakar</label>
													<select class="form-control" name="bhavan_parkar" id="bhavan_parkar" onchange="get_surveyor_list();" required>
								                         <option value="">--Select--</option>
													</select>
												</div>
											</div>
                                            <div class="col-sm-2">
												<div class="form-group">
													<label class="control-label">Farsh Ka Prakar</label>
													<select class="form-control" name="farsh_prakar" id="farsh_prakar"  required>
								                         <option value="">--Select--</option>
													</select>
												</div>
											</div>
											<div class="col-sm-2">
												<div class="form-group">
													<label class="control-label">Sadak Ki Chaudai</label>
													<select class="form-control" name="sadak_chaudai" id="sadak_chaudai" required>
								                         <option value="">--Select--</option>
													</select>
												</div>
											</div>
											<div class="col-sm-1">
												<div class="form-group">
													<label class="control-label">Rate</label>
													{!!Form::text('rate','',array('class'=>'form-control','placeholder'=>'Enter Rate'), ['required'])!!}
												</div>
											</div>
											@if($user_access[0]->fn_add=='Y')
									         <div class="col-sm-1" style="margin-top:20px">

										          {!!Form::submit('submit',array('class'=>'btn btn-danger text-uppercase '))!!}

									            </div>
									        @endif
										</div>

									</div>

								{!!Form::Close()!!}
								<!--===================================================-->
								<!--End Block Styled Form -->

							</div>
						</div>

					</div>
					@endif
					<div class="panel">
						<div class="panel-body">
					      <div class="table-responsive">
								<table class="table table-striped table-bordered" cellspacing="0" width="100%">
									<thead>
										<tr>
											<th>Sr.no.</th>
											 <th>Nagar Palika</th>
											 <th>Bhavan Ka Prakar</th>
											 {{-- <th>Farsh Ka Prakar</th> --}}
											 <th>Sadka Ki Chaudai</th>
											 <th>Rate(Rs.)</th>
											 <th>Action</th>
										</tr>
									</thead>
									<tbody>
										@foreach($tax_rate as $index=>$value)
										<tr>
											<td>{{($tax_rate->currentpage()-1) * $tax_rate->perpage() + $index + 1 }}</td>

											<td>{{$value->city}}</td>
											<td>{{$value->bhawan_ka_prakar}}</td>
											{{-- <td>{{$value->farsh_ka_prakar}}</td> --}}
											<td>{{$value->sadak_ki_choudai}}</td>
											<td>{{$value->rate}}</td>
											<td>
											@if($user_access[0]->fn_delete=='Y')
											<form method="post" id="delete_form_{{ $value->id }}"
												action="{{ url('/') }}/Delete-TaxRate">
												{{ csrf_field() }}
												<input type="hidden" name="deleted_id" value="{{ $value->id }}">
												<span onclick="deleteRow('{{ $value->id }}')" type="button"
													class="label label-danger" title="Click to delete this row">Delete</span>
											</form>
											@endif
											@if ($user_access[0]->fn_update == 'Y')
											<a class="label label-success" href="{{ url('/') }}/UpadteTaxRateDetail?id={{ $value->id }}">Edit</a>
										   @endif
											</td>


										</tr>
										@endforeach
									</tbody>
								</table>
							</div>
							{{$tax_rate->links()}}
						</div>
					</div>
				</div>

			</div>


	@endsection

	@section('script');
	<script>
		$('document').ready(function(e){
			city();
		});
		function city()
		{

			$.ajax
			({
				url:"{{url('/')}}/getnagarpalika",
				dataType:'json',
				success:function(data)
				{
					var msg='<option value="">--Select Nagar Palika--</option>';
					for(var i=0;i<data.length;i++)
					{
						msg=msg+'<option value="'+data[i].city+'">'+data[i].city+'</option>';
					}
					$("#nagarpalika").html(msg);
				}
			});
		}
		function get_ward_number(value)
		{

			$.ajax
			({
				url:"{{url('/')}}/getwardnum/"+value,
				dataType:'json',
				success:function(data)
				{
					var msg='<option value="">--Select Ward Number--</option>';
					for(var i=0;i<data.length;i++)
					{
						msg=msg+'<option value="'+data[i].id+'">'+data[i].ward_number+'->'+data[i].ward_name+'->'+data[i].mohalla_name+'</option>';
					}
					$("#ward_number").html(msg);
				}
			});
		}


	$.ajax({
		url:"{{url('/')}}/new_gis/bpage.php?action=selectHouseDetails",
		dataType:"json",
		success:function(data){
			console.log(data);

			var NirmanPrakriti=data.NirmanPrakriti;
			$("#bhavan_parkar").html();
			for(var i=1;i<NirmanPrakriti.length;i++)
			{
				$("#bhavan_parkar").append('<option value="'+NirmanPrakriti[i]+'">'+NirmanPrakriti[i]+'</option>');
			}
			var FarshPrakriti=data.FarshPrakriti;
			$("#farsh_prakar").html();
			for(var i=1;i<FarshPrakriti.length;i++)
			{
				$("#farsh_prakar").append('<option value="'+FarshPrakriti[i]+'">'+FarshPrakriti[i]+'</option>');
			}
		}
	});
	function GetRoadwidth()
	{

		var city=$("#nagarpalika").val();
		//alert(city);
		$.ajax({
			url:"{{url('/')}}/get-Road-width/"+city,
			dataType:"json",
			success:function(data)
			{
				var msg='<option value="">--Select--</option>';
				for(var i=0;i<data.length;i++)
				{
					msg=msg+'<option value="'+data[i].road_width+'">'+data[i].road_width+'</option>';
				}
				$("#sadak_chaudai").html(msg);
			}
		});
	}
	function deleteRow(id) {
               swal({
                       title: "Are you sure?",
                       text: "Once deleted, you will not be able to recover this imaginary file!",
                       icon: "warning",
                       buttons: true,
                       dangerMode: true,
                   })
                   .then((willDelete) => {
                       if (willDelete) {
                           $("#delete_form_" + id).submit();
                       } else {
                           swal("Your data is safe!");
                       }
                   });
           }
	</script>

@endsection
















