   @extends('master')
   @section('content');
       <!--CONTENT CONTAINER-->
       <!--===================================================-->
       <div id="content-container">
           <!--Page Title-->
           <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
           <div id="page-title">
               <h1 class="page-header text-overflow">Mange Ward/Mohalla</h1>
           </div>
           <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
           <!--End page title-->
           <!--===================================================-->
           <div id="page-content">
               <!-- Basic Data Tables -->
               <!--===================================================-->
               <div class="panel">
                   <div class="panel-body">
                       @if ($user_access[0]->fn_add == 'Y')
                           <div class="row">
                               <div class="col-md-12">
                                   <a href="{{ url('/') }}/add_ward_mohlla" class="btn btn-info pull-right"
                                       role="button">Add Ward/Mohalla</a>
                               </div>
                           </div>
                       @endif
                       <div class="table-responsive">
                           <table class="table table-striped table-bordered" cellspacing="0" width="100%">
                               <thead>
                                   <tr>
                                       <th>Sr.no.</th>
                                       <th>Nagar Palika</th>
                                       <th>Ward Number</th>
                                       <th>Ward Name</th>
                                       <th>Mohalla Name</th>
                                       <th>Action</th>
                                   </tr>
                               </thead>
                               <tbody>
                                   @foreach ($wardlist as $value)
                                       <tr>
                                           <td>{{ $value->id }}</td>
                                           <td>{{ $value->nagarpalika }}</td>
                                           <td>{{ $value->ward_number }}</td>
                                           <td>{{ $value->ward_name }}</td>
                                           <td>{{ $value->mohalla_name }}</td>
                                           <td>
                                               {{-- @if ($user_access[0]->fn_delete == 'Y')
										<a class="label label-danger" href="#">Delete</a>
										@endif --}}
                                               @if ($user_access[0]->fn_update == 'Y')
                                                   <a href="{{ url('/') }}/UpadteWardDetail?id={{ $value->id }}"
                                                       class="label label-success">Edit</a>
                                               @endif
                                           </td>
                                       </tr>
                                   @endforeach
                               </tbody>
                           </table>
                       </div>
                   </div>
               </div>
               <!--===================================================-->
               <!-- End Striped Table -->
           </div>
       </div>
       <!--===================================================-->
       <!--End page content-->
   @endsection
