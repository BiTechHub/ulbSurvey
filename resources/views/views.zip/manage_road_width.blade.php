   @extends('master')
   @section('content');
       <!--CONTENT CONTAINER-->
       <!--===================================================-->
       <div id="content-container">
           <!--Page Title-->
           <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
           <div id="page-title">
               <h1 class="page-header text-overflow">Mange Road Width</h1>
           </div>
           <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
           <!--End page title-->
           <!--===================================================-->
           <div id="page-content">
               <!-- Basic Data Tables -->
               <!--===================================================-->
               <div class="panel">
                   <div class="panel-body">
                       @if ($user_access[0]->fn_add == 'Y')
                           <div class="row">
                               <div class="col-md-12">
                                   <a href="#" data-target="#demo-default-modal" data-toggle="modal"
                                       class="btn btn-info pull-right" role="button" onclick="city();">Add/Edit Road
                                       Width</a>
                               </div>
                           </div>
                       @endif
                       <div class="table-responsive">
                           <table class="table table-striped table-bordered" cellspacing="0" width="100%">
                               <thead>
                                   <tr>
                                       <th>Sr.no.</th>
                                       <th>Nagarpalika Name</th>
                                       <th>Road Width</th>
                                       <th>Action</th>
                                   </tr>
                               </thead>
                               <tbody>
                                   @foreach ($road_width_list as $index => $value)
                                       <tr>
                                           <td>{{ ($road_width_list->currentpage() - 1) * $road_width_list->perpage() + $index + 1 }}
                                           </td>
                                           <td>{{ $value->nagarpalika }}</td>
                                           <td>{{ $value->road_width }}</td>
                                           <td>
                                               {{-- @if ($user_access[0]->fn_delete == 'Y')
                                                   <a class="label label-danger" href="#">Delete</a>
                                               @endif --}}
                                               @if ($user_access[0]->fn_update == 'Y')
                                                   <a class="label label-success" href="{{ url('/') }}/UpadteRoadWidthDetail?id={{ $value->id }}">Edit</a>
                                               @endif
                                           </td>
                                       </tr>
                                   @endforeach
                               </tbody>
                           </table>
                       </div>
                       {{ $road_width_list->links() }}
                   </div>
               </div>
               <!--===================================================-->
               <!-- End Striped Table -->
           </div>
       </div>
       <div class="modal fade" id="demo-default-modal" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal"
           aria-hidden="true">
           <div class="modal-dialog">
               <div class="modal-content">
                   <!--Modal header-->
                   <div class="modal-header">
                       <button data-dismiss="modal" class="close" type="button">
                           <span aria-hidden="true">&times;</span>
                       </button>
                       <h4 class="modal-title">Add Road Width</h4>
                   </div>
                   <!--Modal body-->
                   {!! Form::Open(['route' => 'Save.RoadWidth']) !!}
                   <div class="modal-body">
                       <div class="row">
                           <div class="col-sm-6">
                               <div class="form-group">
                                   <label class="control-label">Select Nagarpalika</label>
                                   <select class="form-control" name="nagarpalika" id="nagarpalika">
                                       <option value="">--Select Nagarpalika--</option>
                                   </select>
                               </div>
                           </div>
                           <div class="col-sm-6">
                               <div class="form-group">
                                   <label class="control-label">Road Width(In Feat)</label>
                                   {!! Form::text('road_width', '', ['class' => 'form-control', 'placeholder' => 'Enter Road width']) !!}
                               </div>
                           </div>
                       </div>
                   </div>
                   <!--Modal footer-->
                   <div class="modal-footer">
                       <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                       {!! Form::submit('Submit', ['class' => 'btn btn-success text-uppercase']) !!}
                   </div>
                   {!! Form::Close() !!}
               </div>
           </div>
       </div>
       <script>
           function city() {
               $.ajax({
                   url: "{{ url('/') }}/getnagarpalika",
                   dataType: 'json',
                   success: function(data) {
                       var msg = '<option value="">--Select Nagar Palika--</option>';
                       for (var i = 0; i < data.length; i++) {
                           msg = msg + '<option value="' + data[i].city + '">' + data[i].city + '</option>';
                       }
                       $("#nagarpalika").html(msg);
                   }
               });
           }
       </script>
       <!--===================================================-->
       <!--End page content-->
   @endsection
