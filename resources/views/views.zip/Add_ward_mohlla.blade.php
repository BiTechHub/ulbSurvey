
@extends('master')
@section('content');

			<!--CONTENT CONTAINER-->
			<!--===================================================-->
			<div id="content-container">
				
				
				<div id="page-content">
					
				
					<div class="row">
						<div class="col-sm-12">
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Add Ward/Mohlla</h3>
								</div>
					
								<!--Block Styled Form -->
								<!--===================================================-->
								{!!Form::Open(array('route'=>'save.ward-details'))!!}
									<div class="panel-body">
										<div class="row">
										    <div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">NagarPalika</label>
													<select class="form-control" name="ngrpalika" id="nagarpalika" >
								                         <option value="">--Select Nagar Plika--</option>
														 
								                         
													 
								                    </select>
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">Ward Number</label>
													<select class="form-control" name="wardnum">
								                         <option value="">--Select Ward Number--</option>
														 @for($i=1;$i<=100;$i++)
								                         <option value="{{$i}}">{{$i}}</option>
													 @endfor
								                    </select>
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">Ward Name</label>
													{!!Form::text('wardnam','',array('class'=>'form-control','placeholder'=>'Enter Ward name'))!!}
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">Mohlla Name</label>
													{!!Form::text('mohlla','',array('class'=>'form-control','placeholder'=>'Enter Mohlla name'))!!}
												</div>
											</div>
										</div>
										
									</div>
									<div class="panel-footer text-right">
									@if($user_access[0]->fn_add=='Y')
										{!!Form::submit('save',array('class'=>'btn btn-danger text-uppercase'))!!}
									@endif
									</div>
								{!!Form::Close()!!}
								<!--===================================================-->
								<!--End Block Styled Form -->
					
							</div>
						</div>
					
					</div>
				</div>
					
			</div>		
					
		
	

@endsection
			
@section('script')
<script>
	
		function city()
		{
			
			$.ajax
			({
				url:"{{url('/')}}/getnagarpalika",
				dataType:'json',
				success:function(data)
				{
					var msg='<option value="">--Select Nagar Palika--</option>';
					for(var i=0;i<data.length;i++)
					{
						msg=msg+'<option value="'+data[i].city+'">'+data[i].city+'</option>';
					}
					$("#nagarpalika").html(msg);
				}
			});
		}
		$('document').ready(function(e){
			city();
		});
	</script>
@endsection	

		

		

	
		
		



	
	

