   @extends('master')
   @section('content');
       <!--CONTENT CONTAINER-->
       <!--===================================================-->
       <div id="content-container">
           <!--Page Title-->
           <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
           <div id="page-title">
               <h1 class="page-header text-overflow">Mange Discont</h1>
           </div>
           <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
           <!--End page title-->
           <!--===================================================-->
           <div id="page-content">
               <!-- Basic Data Tables -->
               <!--===================================================-->
               <div class="panel">
                   <div class="panel-body">
                       @if ($user_access[0]->fn_add == 'Y')
                           <div class="row">
                               <div class="col-md-12">
                                   <a href="#" data-target="#demo-default-modal" data-toggle="modal"
                                       class="btn btn-info pull-right" role="button" onclick="city();">Add/Edit Discount
                                       Rate</a>
                               </div>
                           </div>
                       @endif
                       <div class="table-responsive">
                           <table class="table table-striped table-bordered" cellspacing="0" width="100%">
                               <thead>
                                   <tr>
                                       <th>Sr.no.</th>
                                       <th>Nagarpalika Name</th>
                                       <th>Discont</th>
                                       <th>Construction Age</th>
                                       <th>Action</th>
                                   </tr>
                               </thead>
                               <tbody>
                                   @foreach ($discount as $index => $value)
                                       <tr>
                                           <td>{{ ($discount->currentpage() - 1) * $discount->perpage() + $index + 1 }}
                                           </td>
                                           <td>{{ $value->nagarpalika }}</td>
                                           <td>{{ $value->discount_rate }}</td>
                                           <td>{{ $value->construction_age }}</td>
                                           <td>
                                               @if ($user_access[0]->fn_delete == 'Y')
                                                   <form method="post" id="delete_form_{{ $value->id }}"
                                                       action="{{ url('/') }}/Delete-Discount">
                                                       {{ csrf_field() }}
                                                       <input type="hidden" name="deleted_id" value="{{ $value->id }}">
                                                       <span onclick="deleteRow('{{ $value->id }}')" type="button"
                                                           class="label label-danger" title="Click to delete this row">Delete</span>
                                                   </form>
                                               @endif
                                               @if ($user_access[0]->fn_update == 'Y')
                                                   <a class="label label-success" href="{{ url('/') }}/UpadteDiscountDetail?id={{ $value->id }}">Edit</a>
                                               @endif
                                           </td>
                                       </tr>
                                   @endforeach
                               </tbody>
                           </table>
                       </div>
                       {{ $discount->links() }}
                   </div>
               </div>
               <!--===================================================-->
               <!-- End Striped Table -->
           </div>
       </div>
       <div class="modal fade" id="demo-default-modal" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal"
           aria-hidden="true">
           <div class="modal-dialog">
               <div class="modal-content">
                   <!--Modal header-->
                   <div class="modal-header">
                       <button data-dismiss="modal" class="close" type="button">
                           <span aria-hidden="true">&times;</span>
                       </button>
                       <h4 class="modal-title">Add Discount</h4>
                   </div>
                   <!--Modal body-->
                   {!! Form::Open(['route' => 'admin.saveDisount']) !!}
                   <div class="modal-body">
                       <div class="row">
                           <div class="col-sm-4">
                               <div class="form-group">
                                   <label class="control-label">Select Nagarpalika</label>
                                   <select class="form-control" name="nagarpalika" id="nagarpalika"
                                       onchange="fill_construction_age();">
                                       <option value="">--Select Nagarpalika--</option>
                                   </select>
                               </div>
                           </div>
                           <div class="col-sm-4">
                               <div class="form-group">
                                   <label class="control-label">Select Construction Age</label>
                                   <select class="form-control" name="consage" id="consage">
                                       <option value="">--Select Construction Age--</option>
                                   </select>
                               </div>
                           </div>
                           <div class="col-sm-4">
                               <div class="form-group">
                                   <label class="control-label">Discount</label>
                                   {!! Form::text('discount', '', ['class' => 'form-control', 'placeholder' => 'Enter Discount Rate']) !!}
                               </div>
                           </div>
                       </div>
                   </div>
                   <!--Modal footer-->
                   <div class="modal-footer">
                       <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                       {!! Form::submit('Submit', ['class' => 'btn btn-success text-uppercase']) !!}
                   </div>
                   {!! Form::Close() !!}
               </div>
           </div>
       </div>
       <script>
           function deleteRow(id) {
               swal({
                       title: "Are you sure?",
                       text: "Once deleted, you will not be able to recover this imaginary file!",
                       icon: "warning",
                       buttons: true,
                       dangerMode: true,
                   })
                   .then((willDelete) => {
                       if (willDelete) {
                           $("#delete_form_" + id).submit();
                       } else {
                           swal("Your data is safe!");
                       }
                   });
           }

           function city() {
               $.ajax({
                   url: "{{ url('/') }}/getnagarpalika",
                   dataType: 'json',
                   success: function(data) {
                       var msg = '<option value="">--Select Nagar Palika--</option>';
                       for (var i = 0; i < data.length; i++) {
                           msg = msg + '<option value="' + data[i].city + '">' + data[i].city + '</option>';
                       }
                       $("#nagarpalika").html(msg);
                   }
               });
           }

           function fill_construction_age() {
               var nagarpalika = $("#nagarpalika").val();
               //alert(nagarpalika);
               $.ajax({
                   url: "{{ url('/') }}/getConstructionAge/" + nagarpalika,
                   dataType: 'json',
                   success: function(data) {
                       console.log(data);
                       var msg = '<option value="">--Select Construction Age--</option>';
                       for (var i = 0; i < data.length; i++) {
                           msg = msg + '<option value="' + data[i].age + '">' + data[i].age + '</option>';
                       }
                       $("#consage").html(msg);
                   }
               });
           }
       </script>
       <!--===================================================-->
       <!--End page content-->
   @endsection
