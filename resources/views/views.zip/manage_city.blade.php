   @extends('master')
   @section('content');
       <!--CONTENT CONTAINER-->
       <!--===================================================-->
       <div id="content-container">
           <!--Page Title-->
           <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
           <div id="page-title">
               <h1 class="page-header text-overflow">Mange City/Nagarpalika</h1>
           </div>
           <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
           <!--End page title-->
           <!--===================================================-->
           <div id="page-content">
               <!-- Basic Data Tables -->
               <!--===================================================-->
               <div class="panel">
                   <div class="panel-body">
                       @if ($user_access[0]->fn_add == 'Y')
                           <div class="row">
                               <div class="col-md-12">
                                   <a href="#" data-target="#demo-default-modal" data-toggle="modal"
                                       class="btn btn-info pull-right" role="button">Add City/Nagarpalika</a>
                               </div>
                           </div>
                       @endif
                       <div class="table-responsive">
                           <table class="table table-striped table-bordered" cellspacing="0" width="100%">
                               <thead>
                                   <tr>
                                       <th>Sr.no.</th>
                                       <th>City Name</th>
                                       <th>ULB Type</th>
                                       <th>Interest %</th>
                                       <th>Action</th>
                                   </tr>
                               </thead>
                               <tbody>
                                   @foreach ($citylist as $value)
                                       <tr>
                                           <td>{{ $value->id }}</td>
                                           <td>{{ $value->city }}</td>
                                           <td>{{ $value->ulb_type }}</td>
                                           <td>{{ $value->interest_rate }}</td>
                                           <td>
                                               {{-- @if ($user_access[0]->fn_delete == 'Y')
                                                   <a class="label label-danger" href="#">Delete</a>
                                               @endif --}}
                                               @if ($user_access[0]->fn_update == 'Y')
                                                   <a class="label label-success" href="{{ url('/') }}/UpadtemanageCity?id={{ $value->id }}">Edit</a>
                                               @endif
                                           </td>
                                       </tr>
                                   @endforeach
                               </tbody>
                           </table>
                       </div>
                   </div>
               </div>
               <!--===================================================-->
               <!-- End Striped Table -->
           </div>
       </div>
       <div class="modal fade" id="demo-default-modal" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal"
           aria-hidden="true">
           <div class="modal-dialog">
               <div class="modal-content">
                   <!--Modal header-->
                   <div class="modal-header">
                       <button data-dismiss="modal" class="close" type="button">
                           <span aria-hidden="true">&times;</span>
                       </button>
                       <h4 class="modal-title">Add City/Nagarpalika</h4>
                   </div>
                   <!--Modal body-->
                   {!! Form::Open(['route' => 'save.city']) !!}
                   <div class="modal-body">
                       <div class="row">
                           <div class="col-sm-6">
                               <div class="form-group">
                                   <label class="control-label">Select State</label>
                                   <select class="form-control" name="state">
                                       <option value="">--Select State--</option>
                                       <option value="34">Uttar Pradesh</option>
                                   </select>
                               </div>
                           </div>
                           <div class="col-sm-6">
                               <div class="form-group">
                                   <label class="control-label">ULB Type</label>
                                   <select class="form-control" name="ulb_type">
                                       <option value="">--Select--</option>
                                       <option value="Nagar Palika Parishad">Nagar Palika Parishad</option>
                                       <option value="Nagar Nigam">Nagar Nigam</option>
                                       <option value="Nagar Panchayat">Nagar Panchayat</option>
                                   </select>
                               </div>
                           </div>
                           <div class="col-sm-6">
                               <div class="form-group">
                                   <label class="control-label">City/Nagarpalika</label>
                                   {!! Form::text('city', '', ['class' => 'form-control', 'placeholder' => 'Enter city/nagarpalika']) !!}
                               </div>
                           </div>
                           <div class="col-sm-6">
                               <div class="form-group">
                                   <label class="control-label">Interest Rate (%)</label>
                                   {!! Form::text('interest_rate', '', ['class' => 'form-control', 'placeholder' => 'Enter Interest Rate']) !!}
                               </div>
                           </div>
                       </div>
                   </div>
                   <!--Modal footer-->
                   <div class="modal-footer">
                       <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                       {!! Form::submit('Submit', ['class' => 'btn btn-success text-uppercase']) !!}
                   </div>
                   {!! Form::Close() !!}
               </div>
           </div>
       </div>
       <!--===================================================-->
       <!--End page content-->
   @endsection
