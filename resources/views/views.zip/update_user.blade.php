		@extends('master')
		@section('content')
			<!--CONTENT CONTAINER-->
				<!--===================================================-->
				<div id="content-container">
					
					<!--Page Title-->
					<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
					<div id="page-title">
						<h1 class="page-header text-overflow">Update User</h1>

						
						
					</div>
					<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
					<!--End page title-->

					<!--Page content-->
					<!--===================================================-->
					<div id="page-content">
						
					
						<div class="row">
							
								<div class="panel">
									
						
									
									<form method="post">
										{{csrf_field()}}
										<div class="panel-body">
											@if($errors->any())
				                  <div class="alert alert-danger">
				                      <ul>
				                          @foreach ($errors->all() as $error)
				                              <li>{{ $error }}</li>
				                          @endforeach
				                      </ul>
				                  </div>
				              @endif
											<div class="row">
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Select User Type</label>
														<select class="form-control" name="user_type">
														  <option value=''>--Select User Type--</option>
														  <option @if($editData->user_type=="Admin") selected @endif value="Admin">Admin</option>
														  <option @if($editData->user_type=="Surveyor") selected @endif value="Surveyor">Surveyor</option>
														  <option @if($editData->user_type=="Data Entry Operator") selected @endif value="DEO">Data Entry Operator</option>
														  <option @if($editData->user_type=="District Admin") selected @endif value="District Admin">District Admin</option>
														  <option @if($editData->user_type=="Parivar Surveyor") selected @endif value="Parivar Surveyor">Parivar Surveyor</option>
														</select>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Select State</label>
														<select class="form-control" name="state" id="state" onchange="city_by_state(this.value);">
														<option value=''>--Select State--</option>
															@foreach($statelist as $value)
																@if($editData->state_id==$value->id)
																	<option selected value='{{ $value->id }}'>{{ $value->state }}</option>
																@else
																	<option value='{{ $value->id }}'>{{ $value->state }}</option>
																@endif
															@endforeach
														</select>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Select City</label>
														<select class="form-control" id="city" name="city">
														</select>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Name</label>
														{!!Form::text('name',$editData->name,array('class'=>'form-control','placeholder'=>'Enter  Name'))!!}
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Mobile</label>
														{!!Form::number('mobile',$editData->contact,array('class'=>'form-control','placeholder'=>'Enter  Name'))!!}
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">User Name</label>
														{!!Form::text('user_name',$editData->username,array('class'=>'form-control','placeholder'=>'Enter  Name'))!!}
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Password</label>
														{!!Form::input('password', 'password', $editData->password,array('value'=>$editData->username,'class'=>'form-control','placeholder'=>'Enter Name'))!!}
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">E-mail Address</label>
														{!!Form::text('email',$editData->email,array('class'=>'form-control','placeholder'=>'Enter  Name'))!!}
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Address</label>
														{!!Form::text('address',$editData->address,array('class'=>'form-control','placeholder'=>'Enter  Name'))!!}
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group">
														<label class="control-label">Login Type</label>
														<select class="form-control" name="login_type">
														  <option value=''>--Select Login Type--</option>
														  <option @if($editData->login_type=="Offline") selected @endif value="Offline">Offline</option>
														  <option @if($editData->login_type=="Online") selected @endif value="Online">Online</option>
														</select>
													</div>
												</div>
											</div>
										</div>
										<div class="panel-footer text-right">
										@if($user_access[0]->fn_update=='Y')
											{!!Form::submit('Update User',array('class'=>'btn btn-success text-uppercase'))!!}
										@endif
										</div>
									</form>
									<!--===================================================-->
									<!--End Block Styled Form -->
						
								</div>
							
							
						</div>
						
					</div>
					<!--===================================================-->
					<!--End page content-->


				</div>
				
				<!--===================================================-->
				<!--END CONTENT CONTAINER-->
            @endsection
			@section('script')
			<script>
				$(document).ready(function(){
					var value=$("#state").val();
					city_by_state(value);
				});
				function city_by_state(value)
				{
					var selected_city="{{$editData->city}}";
					$.ajax
					({
						url:"{{url('/')}}/getcity/"+value,
						dataType:'json',
						success:function(data)
						{
							var msg='<option value="">--Select City--</option>';
							for(var i=0;i<data.length;i++)
							{
								if(selected_city==data[i].city)
								{
									msg=msg+'<option selected value="'+data[i].city+'">'+data[i].city+'</option>';
								}
								else
								{
									msg=msg+'<option value="'+data[i].city+'">'+data[i].city+'</option>';
								}
								
							}
							$("#city").html(msg);
						}
					});
				}
				</script>
				@endsection