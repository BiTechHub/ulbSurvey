
@extends('master')
@section('content');
	
	<div id="content-container">
				
				<!--Page Title-->
				<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
				<div id="page-title">
					<h1 class="page-header text-overflow">User Access</h1>

					<div class="searchbox">
					
						<div class="input-group custom-search-form">
							<input type="text" class="form-control" id="search" onKeyPress="searchFromTable(event,'k');"  placeholder="Search Key Word .....">
							<span class="input-group-btn">
								<button class="text-muted" onClick="searchFromTable(event,'nk');" type="button"><i class="fa fa-search"></i></button>
							</span>
						</div>
					</div>
				</div>
				<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
				<!--End page title-->


				<!--Breadcrumb-->
				<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
				<ol class="breadcrumb">
					<li><a href="dashboard">Home</a></li>
					<li><a href="#">User Access</a></li>
				</ol>
				<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
				<!--End breadcrumb-->


		

				<!--Page content-->
				<!--===================================================-->
				<div id="page-content">
					
					
					
					
					<!--Tiles - Bright Version-->
					<!--===================================================-->
					
					
					
					<!--Sort & Format Column-->
					<!--===================================================-->
					<div class="panel">
						<div class="panel-body">
                        
							<div class="form-group col-sm-4">
									<select id="user" onchange="getDetail(this.value);" class="form-control">
										<option value="">--Select User--</option>
										@foreach($userslist as $value)
											<option value="{{$value->id}}">{{$value->username}}--{{$value->user_type}}</option>
										@endforeach
									</select>
								</div>
                        </div>
					</div>
					<div class="panel">
						<div class="panel-body">
							<div class="table-responsive">
								<table class="table table-striped table-bordered" cellspacing="0" width="100%">
									<thead>
										<tr>
												<th>Sr No.</th>
												<th>Menu</th>
												<th>Sub Menu</th>
												<th>Add</th>
												<th>Edit</th>
												<th>Delete</th>
												<th>View</th>
												<th>Excel</th>
											</tr>
									</thead>
									<tbody id="tData">
											
										</tbody>
								</table>
							</div>
						</div>
					</div>
					
					<!--===================================================-->
					
					
					
					
					
					
					
				</div>
				<!--===================================================-->
				<!--End page content-->


			</div>
	@endsection
	@section('script')
	<script>
		function statusChange(type,id)
		{
			if($('#'+type+''+id).is(':checked')){
				$.ajax({
					url:"{{url('/')}}/changeUserControl",
					data:"id="+id+"&type="+type+"&status=Y",
					type:"get",
					//dataType:'json',
					success:function(data){
						$.niftyNoty({
							type: 'success',
							icon : 'fa fa-check',
							message : "Service Successfully Activated",
							container : 'floating',
							timer : 4000
						});
					}
				});
			 }else{
				  $.ajax({
					url:"{{url('/')}}/changeUserControl",
					data:"id="+id+"&type="+type+"&status=N",
					type:"get",
					//dataType:'json',
					success:function(data){
						$.niftyNoty({
							type: 'danger',
							icon : 'fa fa-warning',
							message : "Service Successfully Deactivated",
							container : 'floating',
							timer : 4000
						});
					}
				});
			 }
			
		}
		function getDetail(id)
		{
			$("#tData").html("");
			$.ajax({
				url:"{{url('/')}}/UserControlList/"+id,
				dataType:'json',
				success:function(data){
					//console.log(data);
					var msg="";
					var fnbtn;
					for(var i=0;i<data.length;i++)
					{
						if(data[i].fn_add=='Y'){fnaddbtn='Checked'}else {fnaddbtn='';}
						if(data[i].fn_delete=='Y'){fndelbtn='Checked'}else {fndelbtn='';}
						if(data[i].fn_update=='Y'){fneditbtn='Checked'}else {fneditbtn='';}
						if(data[i].fn_view=='Y'){fnviewbtn='Checked'}else {fnviewbtn='';}
						if(data[i].fn_excel=='Y'){fnexcelbtn='Checked'}else {fnexcelbtn='';}
						msg=msg+'<tr><td>'+(parseInt(i)+1)+'</td>'+
						'<td>'+data[i].menu_name+'</td>'+
						'<td>'+data[i].sub_menu+'</td>'+
						'<td><input type="checkbox" id="add'+data[i].id+'" onchange="statusChange(\'add\','+data[i].id+');" '+fnaddbtn+'></td>'+
						'<td><input type="checkbox" id="edit'+data[i].id+'" onchange="statusChange(\'edit\','+data[i].id+');" '+fneditbtn+'></td>'+
						'<td><input type="checkbox" id="delete'+data[i].id+'" onchange="statusChange(\'delete\','+data[i].id+');" '+fndelbtn+'></td>'+
						'<td><input type="checkbox" id="view'+data[i].id+'" onchange="statusChange(\'view\','+data[i].id+');" '+fnviewbtn+'></td>'+
						'<td><input type="checkbox" id="excel'+data[i].id+'" onchange="statusChange(\'excel\','+data[i].id+');" '+fnexcelbtn+'></td></tr>';
					}
					$("#tData").html(msg);
				}
			});
		}
	</script>
	@endsection

			
			

		

		

	
		
		



	
	

